document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('#feedback');
    const inputName = document.querySelector('#FirstName');
    const inputLName = document.querySelector('#LastName');
    const ratingIn = document.querySelector('#Rating');
    const messageIn = document.querySelector('#comment');
    const list = document.querySelector('#feedback-item');
    let feedcount = 0;

    function feedbacklists(fullname, rating, comment) {
        const feedlist = document.createElement('div');
        feedlist.classList.add('list');
        feedlist.innerHTML = `
      <strong style="color: #27548A;">${fullname || 'N/A'}</strong><br>
      <strong style="color: #27548A;">Rating: ${rating} / 5</strong>
      <p><strong style="color: #27548A;">Comment:</strong> ${comment}</p>
      <hr>
    `;
        list.appendChild(feedlist);

    }
    function cleary() {
        inputName.value = '';
        inputLName.value = '';
        ratingIn.value = '0';
        messageIn.value = '';
    }
    function clearfeed() {
        list.innerHTML = '';
    }
// when submit form top get a value of input and combine name to fullname
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const firstname = inputName.value.trim().toUpperCase();
        const lastname = inputLName.value.trim().toUpperCase();
        const rating = ratingIn.value;
        const message = messageIn.value.trim();

        if (!message || rating === '') return; // if not input message or rating can't submit

        const fullname = `${firstname} ${lastname}`.trim();
        feedbacklists(fullname, rating, message);
        feedcount++;
        if (feedcount === 100) {
            list.innerHTML = '';
        }
        cleary(); // clear form after feedback show as a class in div feedback-tem
    });

    form.addEventListener('reset', (e) => {
        e.preventDefault();
        cleary();
    });
});