document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('#feedback');
    const inputName = document.querySelector('#FirstName');
    const inputLName = document.querySelector('#LastName');
    const ratingIn = document.querySelector('#Rating');
    const messageIn = document.querySelector('#comment');
    const list = document.querySelector('#feedback-item');
    let feedcount = 0; // use let feedcount to make it can access in form.addEventListener

    // This function feedbacklist is function to add feedlist in the HTML file after
    // input the information by if not input name or lastname it will show as N/A in the part of feedback list
    function feedbacklists(fullname, rating, comment) {
        const feedlist = document.createElement('div');
        feedlist.classList.add('list');
        feedlist.innerHTML = `
      <strong style="color: #27548A;">${fullname || 'N/A'}</strong><br>
      <strong style="color: #27548A;">Rating: ${rating} / 5</strong>
      <p><strong style="color: #27548A;">Comment:</strong> ${comment}</p>
      <hr>
    `;
        list.appendChild(feedlist); // Add list ad a child of feedlist

    }
    function cleary() { //function for reset button to clear all value in input
        inputName.value = '';
        inputLName.value = '';
        ratingIn.value = '0';
        messageIn.value = '';
    }
    function clearfeed() {
        list.innerHTML = '';
    }
// when submit form top get a value of input and combine name to fullname
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const firstname = inputName.value.trim().toUpperCase(); // adjust all firstname to be uppercase
        const lastname = inputLName.value.trim().toUpperCase(); // adjust all lastname to be uppercase
        const rating = ratingIn.value;
        const message = messageIn.value.trim();

        if (!message || rating === '') return; // if not input message or rating can't submit

        const fullname = `${firstname} ${lastname}`.trim();
        feedbacklists(fullname, rating, message);
        feedcount++;
        if (feedcount === 100) { // this loop if feedback list count until 100
            // it will reset all list inside feedback list
            list.innerHTML = '';
        }
        cleary(); // clear form after feedback show as a class in div feedback-tem
    });

    form.addEventListener('reset', (e) => { //this after click reset button it will executing
        // function cleary to cleary all value that user input but don't wanna submit 
        e.preventDefault();
        cleary();
    });
});