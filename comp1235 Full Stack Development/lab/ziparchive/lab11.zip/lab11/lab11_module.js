/* javascript module
purpose
- To create a seperate module ( file ) ad then exporting variable
  from the file then import variable to 3rd files

 */
export {greeter,username, id}
let username = "Vissarut.Promkaew"
let id = "275"


function greeter () {
    console.log ("welcome to the website")
}
