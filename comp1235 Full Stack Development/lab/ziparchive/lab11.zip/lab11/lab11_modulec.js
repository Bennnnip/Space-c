/* lab11_module
purpose :
Demonstate that you can have 2 files with the same
fucntion name
 */
export  {greeter}
function greeter () {
    console.log("welcome to the website - admin")
}